# Deutsch A1 Premium

A1-only German learning app: 1000 curated beginner vocabulary entries, Arabic meanings, German TTS, A1 grammar, Hören, Schreiben, hearts and XP.

The 1000 entries are a curated A1-range learning set, not an official Goethe word list.
