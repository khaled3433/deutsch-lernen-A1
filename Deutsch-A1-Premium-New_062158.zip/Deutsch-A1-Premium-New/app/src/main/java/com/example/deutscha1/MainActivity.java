package com.example.deutscha1;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(9,11,18), CARD=Color.rgb(19,23,34), CARD2=Color.rgb(28,34,49), TEXT=Color.rgb(245,247,252), MUTED=Color.rgb(165,173,191), GOLD=Color.rgb(232,185,74), BLUE=Color.rgb(76,145,255), GREEN=Color.rgb(65,205,145), RED=Color.rgb(245,92,102);
    LinearLayout content; TextView heartsView,xpView; TextToSpeech tts; SharedPreferences prefs; int hearts=5,xp=0;
    static class Word {String de,ar,cat; Word(String d,String a,String c){de=d;ar=a;cat=c;}}
    ArrayList<Word> words=new ArrayList<>(); HashSet<String> fav=new HashSet<>(); Random rnd=new Random();
    String[][] grammar={
      {"Ich ___ aus Berlin.","komme","kommt","kommen","komme"},{"Du ___ Deutsch.","lernst","lernt","lernen","lernst"},{"Er ___ müde.","ist","bin","bist","ist"},{"Wir ___ in Hamburg.","wohnen","wohnt","wohnst","wohnen"},
      {"___ Haus ist groß.","Das","Die","Der","Das"},{"___ Frau ist nett.","Die","Das","Der","Die"},{"Ich habe ___ Bruder.","einen","eine","ein","einen"},{"Ich sehe ___ Tasche.","die","den","das","die"},
      {"___ wohnst du?","Wo","Wer","Was","Wo"},{"___ heißt du?","Wie","Wo","Wann","Wie"},{"___ kommst du?","Woher","Wohin","Wer","Woher"},{"___ gehst du?","Wohin","Woher","Was","Wohin"},
      {"___ ist dein Geburtstag?","Wann","Wer","Wo","Wann"},{"___ ist das?","Wer","Wo","Wie","Wer"},{"___ kostet das?","Wie viel","Wo","Wann","Wie viel"},{"Ich komme ___ Deutschland.","aus","mit","für","aus"},
      {"Ich fahre ___ dem Bus.","mit","aus","für","mit"},{"Das ist ___ Auto.","ein","eine","einen","ein"},{"Das ist ___ Lampe.","eine","ein","einen","eine"},{"___ du Deutsch?","Sprichst","Spricht","Spreche","Sprichst"},
      {"___ Sie bitte langsam!","Sprechen","Sprich","Sprecht","Sprechen"},{"___ das Fenster auf!","Mach","Macht","Machen","Mach"},{"Kommt ihr morgen? — ___, wir kommen.","Ja","Nein","Doch","Ja"},{"Kommt ihr heute nicht? — ___, wir kommen.","Doch","Ja","Nein","Doch"},
      {"Mein Bruder ist nett. ___ ist 20.","Er","Sie","Es","Er"},{"Anna ist hier. ___ lernt Deutsch.","Sie","Er","Es","Sie"},{"Das Kind spielt. ___ ist glücklich.","Es","Er","Sie","Es"},{"___ Bücher sind neu.","Die","Der","Das","Die"},
      {"Ich ___ einen Kaffee.","trinke","trinkt","trinkst","trinke"},{"Sie ___ heute nicht.","arbeitet","arbeiten","arbeite","arbeitet"}
    };
    String[][] listening={
      {"Bahnhof","Der Zug nach Berlin fährt heute um zehn Uhr ab. Bitte gehen Sie zu Gleis drei.","10 Uhr","8 Uhr","12 Uhr","10 Uhr"},
      {"Arzt","Guten Tag. Ihr Termin beim Arzt ist am Montag um neun Uhr.","Montag","Dienstag","Freitag","Montag"},
      {"Supermarkt","Entschuldigung, wo ist die Milch? — Die Milch ist dort, neben dem Käse.","Neben dem Käse","Neben dem Brot","Bei der Kasse","Neben dem Käse"},
      {"Telefon","Hallo Maria, ich komme heute um sechs Uhr. Wir treffen uns vor dem Kino.","6 Uhr","5 Uhr","7 Uhr","6 Uhr"},
      {"Wetter","Heute ist es kalt und regnet. Morgen scheint die Sonne.","Morgen scheint die Sonne","Heute ist es heiß","Morgen schneit es","Morgen scheint die Sonne"},
      {"Einkaufen","Ich brauche zwei Brötchen und ein Kilo Äpfel.","Zwei Brötchen und ein Kilo Äpfel","Ein Brot und zwei Bananen","Drei Brötchen","Zwei Brötchen und ein Kilo Äpfel"},
      {"Familie","Mein Bruder heißt Ali. Er ist 18 Jahre alt.","18","16","20","18"},
      {"Bus","Der Bus Nummer fünf fährt zum Bahnhof.","5","4","6","5"},
      {"Arbeit","Ich arbeite von acht bis vier Uhr.","8 bis 4","9 bis 5","7 bis 3","8 bis 4"},
      {"Treffen","Wir treffen uns am Samstag im Park.","Samstag im Park","Sonntag im Café","Freitag zu Hause","Samstag im Park"}
    };
    String[][] writing={
      {"Vorstellung","Schreibe: Name, Alter, Land und Wohnort.","Ich heiße … Ich bin … Jahre alt. Ich komme aus … Ich wohne in …"},
      {"Familie","Schreibe zwei oder drei Sätze über deine Familie.","Meine Familie ist … Ich habe …"},
      {"Termin","Du kannst morgen nicht kommen. Schreibe eine kurze Nachricht.","Hallo …, ich kann morgen nicht kommen. Können wir …? Viele Grüße …"},
      {"Einkaufen","Schreibe, was du im Supermarkt kaufen möchtest.","Ich möchte … kaufen. Ich brauche auch …"},
      {"Alltag","Schreibe drei Sätze über deinen Tag.","Ich stehe um … auf. Dann … Am Abend …"},
      {"Wohnung","Beschreibe deine Wohnung mit drei einfachen Sätzen.","Meine Wohnung ist … Sie hat … Mein Zimmer ist …"},
      {"Hobby","Schreibe über ein Hobby.","Mein Hobby ist … Ich … gern."},
      {"Einladung","Lade einen Freund zu einem Treffen ein.","Hallo …, möchtest du am … mit mir …? Liebe Grüße …"},
      {"Arbeit/Schule","Schreibe, wo du arbeitest oder lernst.","Ich arbeite/lerne in … Ich …"},
      {"Urlaub","Schreibe drei einfache Sätze über deinen Urlaub.","Ich bin in … Das Wetter ist … Ich …"}
    };
    @Override public void onCreate(Bundle b){super.onCreate(b); loadData(); prefs=getSharedPreferences("state",0); hearts=prefs.getInt("hearts",5); xp=prefs.getInt("xp",0); fav.addAll(prefs.getStringSet("fav",new HashSet<>())); tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS){tts.setLanguage(Locale.GERMAN);tts.setSpeechRate(.86f);}}); home();}
    void loadData(){try{InputStream in=getAssets().open("words.json");ByteArrayOutputStream bo=new ByteArrayOutputStream(); byte[] bb=new byte[4096]; int nn; while((nn=in.read(bb))!=-1) bo.write(bb,0,nn); String s=new String(bo.toByteArray(),StandardCharsets.UTF_8);Pattern p=Pattern.compile("\\{\\s*\\\"de\\\"\\s*:\\s*\\\"(.*?)\\\"\\s*,\\s*\\\"ar\\\"\\s*:\\s*\\\"(.*?)\\\"\\s*,\\s*\\\"cat\\\"\\s*:\\s*\\\"(.*?)\\\"\\s*\\}",Pattern.DOTALL);Matcher m=p.matcher(s);while(m.find())words.add(new Word(unesc(m.group(1)),unesc(m.group(2)),unesc(m.group(3))));}catch(Exception e){Toast.makeText(this,"Vocabulary error",Toast.LENGTH_LONG).show();}}
    String unesc(String s){return s.replace("\\\\\"","\"").replace("\\n"," ");}
    void save(){prefs.edit().putInt("hearts",hearts).putInt("xp",xp).putStringSet("fav",fav).apply();}
    TextView tv(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setPadding(3,3,3,3);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(18,16,18,16);c.setBackground(bg(CARD,22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,7,0,7);c.setLayoutParams(p);return c;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(TEXT);b.setAllCaps(false);b.setBackground(bg(CARD2,16));b.setPadding(10,8,10,8);return b;}
    void base(String title){content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(18,18,18,24);content.setBackgroundColor(BG);ScrollView sc=new ScrollView(this);sc.addView(content);setContentView(sc);LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView t=tv(title,24,TEXT,true);top.addView(t,new LinearLayout.LayoutParams(0,-2,1));Button back=btn("‹");back.setOnClickListener(v->home());top.addView(back,new LinearLayout.LayoutParams(55,55));content.addView(top);}
    void header(){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(0,4,0,8);heartsView=tv("❤️ "+hearts,16,RED,true);xpView=tv("⚡ "+xp+" XP",16,GOLD,true);r.addView(heartsView,new LinearLayout.LayoutParams(0,-2,1));r.addView(xpView);content.addView(r);}
    void home(){base("Deutsch A1 Premium");header();content.addView(tv("A1 فقط • تعلم خطوة بخطوة",14,MUTED,false));content.addView(tv("1000 مفردة A1 + قواعد + Hören + Schreiben",16,TEXT,true));String[] names={"📚 الكلمات","🧠 القواعد","🎧 Hören","✍️ Schreiben"};String[] subs={"1000 كلمة ألمانية مع العربي والنطق","تمارين A1 قصيرة وتدريجية","10 تمارين استماع A1 مع TTS","مهام كتابة مثل مواقف الامتحان"};for(int i=0;i<4;i++){final int x=i;LinearLayout c=card();c.addView(tv(names[i],21,TEXT,true));c.addView(tv(subs[i],13,MUTED,false));Button b=btn("ابدأ →");b.setOnClickListener(v->{if(x==0)words();if(x==1)grammar();if(x==2)listening();if(x==3)writing();});c.addView(b);content.addView(c);}LinearLayout stats=card();stats.addView(tv("تقدمك",18,TEXT,true));stats.addView(tv("❤️ "+hearts+"    ⚡ "+xp+" XP    📚 "+words.size()+" كلمة",15,MUTED,false));content.addView(stats);}
    void words(){base("📚 كلمات A1");header();LinearLayout searchRow=new LinearLayout(this);EditText q=new EditText(this);q.setHint("ابحث بالألماني أو العربي");q.setTextColor(TEXT);q.setHintTextColor(MUTED);q.setSingleLine();searchRow.addView(q,new LinearLayout.LayoutParams(0,60,1));Button s=btn("بحث");searchRow.addView(s,new LinearLayout.LayoutParams(90,60));content.addView(searchRow);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);Runnable render=()->{list.removeAllViews();String term=q.getText().toString().trim().toLowerCase(Locale.ROOT);int shown=0;for(Word w:words){if(term.length()>0&&!w.de.toLowerCase(Locale.ROOT).contains(term)&&!w.ar.contains(term))continue;LinearLayout c=card();LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView de=tv(w.de,19,TEXT,true);row.addView(de,new LinearLayout.LayoutParams(0,-2,1));Button play=btn("🔊");play.setOnClickListener(v->speak(w.de));Button f=btn(fav.contains(w.de)?"★":"☆");f.setOnClickListener(v->{if(fav.contains(w.de))fav.remove(w.de);else fav.add(w.de);save();f.setText(fav.contains(w.de)?"★":"☆");});row.addView(play,new LinearLayout.LayoutParams(58,52));row.addView(f,new LinearLayout.LayoutParams(58,52));c.addView(row);c.addView(tv(w.ar+"  •  "+w.cat,13,MUTED,false));list.addView(c);if(++shown>=80&&term.isEmpty())break;}};s.setOnClickListener(v->render.run());q.setOnEditorActionListener((v,a,e)->{render.run();return true;});render.run();}
    void speak(String s){if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"a1");}
    void grammar(){base("🧠 قواعد A1");header();quiz(grammar, "grammar");}
    void listening(){base("🎧 Hören A1");header();content.addView(tv("5 تمارين بنص مكتوب + 5 بدون نص. استخدم زر 🔊 للاستماع.",13,MUTED,false));for(int i=0;i<listening.length;i++){final int ix=i;LinearLayout c=card();c.addView(tv((i+1)+". "+listening[i][0],18,TEXT,true));c.addView(tv(i<5?"نص الاستماع: "+listening[i][1]:"استماع صوتي فقط",14,MUTED,false));Button play=btn("🔊 تشغيل الألماني");play.setOnClickListener(v->speak(listening[ix][1]));c.addView(play);TextView q=tv("السؤال: ماذا فهمت؟",15,TEXT,true);c.addView(q);for(int j=1;j<=3;j++){final int jj=j;Button o=btn(listening[i][j]);o.setOnClickListener(v->{if(listening[ix][4].equals(o.getText().toString()))good(c);else bad();});c.addView(o);}content.addView(c);}}
    void quiz(String[][] qs,String kind){for(int i=0;i<qs.length;i++){final int ix=i;LinearLayout c=card();c.addView(tv("تمرين "+(i+1),13,GOLD,true));c.addView(tv(qs[i][0],17,TEXT,true));for(int j=1;j<=3;j++){Button o=btn(qs[i][j]);o.setOnClickListener(v->{if(qs[ix][4].equals(o.getText().toString())){good(c);}else bad();});c.addView(o);}content.addView(c);}}
    void good(LinearLayout c){xp+=10;if(hearts<5)hearts++;save();Toast.makeText(this,"صح! +10 XP",Toast.LENGTH_SHORT).show();header();}
    void bad(){hearts=Math.max(0,hearts-1);save();Toast.makeText(this,"حاول مرة ثانية ❤️",Toast.LENGTH_SHORT).show();if(hearts==0){hearts=5;Toast.makeText(this,"رجعنا القلوب إلى 5 للمتابعة",Toast.LENGTH_LONG).show();save();}}
    void writing(){base("✍️ Schreiben A1");header();content.addView(tv("اكتب إجابتك بالألماني. هذه مهام قصيرة بمستوى A1.",14,MUTED,false));for(int i=0;i<writing.length;i++){final int ix=i;LinearLayout c=card();c.addView(tv((i+1)+". "+writing[i][0],18,TEXT,true));c.addView(tv(writing[i][1],14,MUTED,false));EditText e=new EditText(this);e.setMinLines(3);e.setGravity(Gravity.TOP);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setHint("اكتب هنا بالألماني...");e.setBackground(bg(CARD2,14));c.addView(e);Button check=btn("إظهار نموذج A1");check.setOnClickListener(v->{c.addView(tv("نموذج: "+writing[ix][2],14,GREEN,true));xp+=5;save();});c.addView(check);content.addView(c);}}
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
